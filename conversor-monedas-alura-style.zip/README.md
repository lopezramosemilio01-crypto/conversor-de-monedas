
# Conversor de Monedas 💱

Proyecto realizado en Java que consume una API de tasas de cambio para convertir monedas.

## Tecnologías utilizadas
- Java 17
- HttpClient
- Gson
- API ExchangeRate

## Funcionalidades
- Conversión entre USD, ARS, BRL y COP
- Menú interactivo en consola
- Consumo de API externa
- Procesamiento de JSON con Gson

## Ejecución
1. Clonar repositorio
2. Ejecutar `mvn clean install`
3. Ejecutar clase `Principal`
