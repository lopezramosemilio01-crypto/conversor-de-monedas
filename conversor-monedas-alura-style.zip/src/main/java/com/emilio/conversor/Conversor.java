
package com.emilio.conversor;

public class Conversor {

    ConsultaAPI api = new ConsultaAPI();

    public void convertir(int opcion, double valor){

        switch (opcion){

            case 1 -> mostrarResultado("USD","ARS",valor);
            case 2 -> mostrarResultado("ARS","USD",valor);
            case 3 -> mostrarResultado("USD","BRL",valor);
            case 4 -> mostrarResultado("BRL","USD",valor);
            case 5 -> mostrarResultado("USD","COP",valor);
            case 6 -> mostrarResultado("COP","USD",valor);
            default -> System.out.println("Opción inválida");
        }
    }

    private void mostrarResultado(String base, String destino, double valor){

        double tasa = api.obtenerTasa(base, destino);
        double resultado = valor * tasa;

        System.out.println("El valor convertido es: " + resultado + " " + destino);
    }
}
