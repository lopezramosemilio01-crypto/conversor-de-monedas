
package com.emilio.conversor;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {

        Scanner lectura = new Scanner(System.in);
        Conversor conversor = new Conversor();
        int opcion = 0;

        while (opcion != 7) {

            System.out.println("""
            *******************************
            Sea bienvenido al Conversor de Monedas

            1) USD -> ARS
            2) ARS -> USD
            3) USD -> BRL
            4) BRL -> USD
            5) USD -> COP
            6) COP -> USD
            7) Salir
            *******************************
            """);

            opcion = lectura.nextInt();

            if (opcion == 7) {
                System.out.println("Programa finalizado");
                break;
            }

            System.out.println("Ingrese el valor que desea convertir:");
            double valor = lectura.nextDouble();

            conversor.convertir(opcion, valor);
        }
    }
}
