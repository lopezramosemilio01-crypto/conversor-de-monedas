
package com.emilio.conversor;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ConsultaAPI {

    public double obtenerTasa(String base, String destino){

        String apiKey = "https://api.exchangerate.host/convert?from=" + base + "&to=" + destino + "&amount=1";

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiKey))
                .GET()
                .build();

        try {

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();

            return json.get("result").getAsDouble();

        } catch (IOException | InterruptedException e) {
            throw new RuntimeException("Error al consultar la API", e);
        }
    }
}
